# NextBall

.wrapで括ってレスポンシブ化。
現在の最大横幅は640px。
